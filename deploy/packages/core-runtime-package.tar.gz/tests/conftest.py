"""
Pytest Configuration and Fixtures for Contract Kit Tests.

Provides shared fixtures for runtime API, event bus, and
hermes orchestrator testing.
"""

import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from typing import Generator


@pytest.fixture(scope="session")
def event_loop() -> Generator:
    """
    Create an event loop for the test session.
    
    Yields:
        The event loop instance.
    """
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def mock_runtime_api():
    """Create a mock RuntimeCoreAPI for testing."""
    mock_api = MagicMock()
    mock_api.get_settings = AsyncMock(return_value={
        "setting_a": "value_a",
        "setting_b": "value_b"
    })
    mock_api.update_setting = AsyncMock(return_value={
        "key": "test_key",
        "value": "test_value",
        "updated": True
    })
    mock_api.health_check = AsyncMock(return_value={
        "status": "healthy",
        "components": {
            "runtime_api": "healthy",
            "event_bus": "healthy"
        }
    })
    return mock_api


@pytest.fixture
def runtime_core_api():
    """Create a RuntimeCoreAPI instance for testing."""
    from src.runtime import RuntimeCoreAPI
    api = RuntimeCoreAPI(title="Test Runtime", version="1.0.0")
    return api


@pytest.fixture
def event_bus():
    """Create an EventBus instance for testing."""
    from src.runtime import EventBus
    bus = EventBus(nats_url="nats://localhost:4222")
    return bus


@pytest.fixture
def hermes_orchestrator(mock_runtime_api):
    """Create a HermesOrchestrator instance for testing."""
    from src.hermes import HermesOrchestrator
    orchestrator = HermesOrchestrator(
        runtime_api=mock_runtime_api,
        event_bus=None,
        provider_router=None
    )
    return orchestrator


@pytest.fixture
def mock_provider_router():
    """Create a mock ProviderRouter for testing."""
    mock_router = MagicMock()
    mock_router.route = AsyncMock(return_value={
        "status": "success",
        "provider": "provider-a",
        "response": {"result": "ok"}
    })
    mock_router.get_provider_health = AsyncMock(return_value={
        "provider": "provider-a",
        "status": "healthy",
        "latency_ms": 50
    })
    return mock_router


@pytest.fixture
def sample_contract():
    """Create a sample contract for testing."""
    return {
        "contract_id": "contract-test-1",
        "status": "active",
        "request_type": "contract_review",
        "normalized_content": "Test contract content",
        "tasks": [],
        "evidence": []
    }


@pytest.fixture
def sample_evidence():
    """Create sample evidence items for testing."""
    return [
        {
            "evidence_id": "ev-1",
            "type": "screenshot",
            "content": "test screenshot data",
            "timestamp": "2024-01-15T10:30:00Z"
        },
        {
            "evidence_id": "ev-2",
            "type": "log",
            "content": "test log output",
            "timestamp": "2024-01-15T10:31:00Z"
        }
    ]


@pytest.fixture(autouse=True)
def reset_singletons():
    """Reset singleton states between tests."""
    yield
