"""
Hermes End-to-End Tests.

Tests the Hermes orchestrator including intake normalization,
contract creation, and task fanout.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch


@pytest.fixture
def hermes_orchestrator():
    """Create a HermesOrchestrator instance for testing."""
    from src.hermes import HermesOrchestrator
    orchestrator = HermesOrchestrator(
        runtime_api=None,
        event_bus=None,
        provider_router=None
    )
    return orchestrator


@pytest.mark.asyncio
async def test_intake_normalization(hermes_orchestrator):
    """
    Test intake normalization of raw input.
    
    Verifies that raw input is properly normalized,
    validated, and prepared for contract creation.
    """
    raw_input = {
        "request_type": "contract_review",
        "source": "email",
        "raw_content": "Please review contract version 2.3",
        "metadata": {
            "sender": "client@example.com",
            "timestamp": "2024-01-15T10:30:00Z"
        }
    }
    
    result = await hermes_orchestrator.intake(raw_input)
    assert isinstance(result, dict)
    assert "normalized" in result or "request_id" in result


@pytest.mark.asyncio
async def test_contract_creation(hermes_orchestrator):
    """
    Test contract creation from normalized input.
    
    Verifies that contracts are created with proper IDs,
    initial status, and required fields.
    """
    normalized_input = {
        "request_id": "req-123",
        "request_type": "contract_review",
        "normalized_content": "Review contract version 2.3",
        "priority": "normal"
    }
    
    contract = await hermes_orchestrator.contract_creation(normalized_input)
    assert isinstance(contract, dict)
    assert "contract_id" in contract or "id" in contract


@pytest.mark.asyncio
async def test_task_fanout(hermes_orchestrator):
    """
    Test task fanout to providers.
    
    Verifies that tasks are properly distributed across
    available providers and tracked correctly.
    """
    with patch.object(hermes_orchestrator.provider_router, 'route') as mock_route:
        mock_route.return_value = {"status": "dispatched", "task_id": "task-1"}
        
        hermes_orchestrator.contracts["contract-1"] = {
            "contract_id": "contract-1",
            "status": "active",
            "tasks": []
        }
        
        tasks = await hermes_orchestrator.task_fanout("contract-1")
        assert isinstance(tasks, list)
